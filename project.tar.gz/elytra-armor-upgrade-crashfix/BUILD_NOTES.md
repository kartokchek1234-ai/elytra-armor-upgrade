# Build notes

- This environment cannot produce the actual mod JAR because it has JDK 21 only, no installed Gradle distribution, no cached Fabric/Minecraft dependencies, and DNS/network access to dependency repositories is unavailable.
- A genuine JAR has intentionally not been fabricated from stubs.
- `build.gradle` was aligned with the Fabric 26.3 example project: no mappings dependency for unobfuscated 26.x Minecraft, `implementation` dependencies, Java 25, Loom 1.18-SNAPSHOT, Fabric API 0.163.0+26.3, Gradle 9.7.1.
- CI builds must still compile and pass before the output can be described as working.
