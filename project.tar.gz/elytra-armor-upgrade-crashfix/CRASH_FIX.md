Crash report analysis
=====================

Observed failure:
`NullPointerException: Components not bound yet`
`Item.getDefaultInstance -> ModItems.properties -> ModItems.<clinit>`

Root cause: `Items.ELYTRA.getDefaultInstance()` called while the mod's static item registration runs, before Minecraft has bound item components.

Fix: create `DataComponents.EQUIPPABLE` from `Equippable.builder(EquipmentSlot.CHEST)` without constructing any `ItemStack`.
