# Бронированные элитры — Minecraft Java 26.3 + Fabric

## Текущий статус

В исходниках исправлен вылет из предоставленного crash report: во время статической инициализации `ModItems` больше не создаётся ранний `ItemStack` через `Items.ELYTRA.getDefaultInstance()`. Компонент экипировки строится напрямую через `Equippable.builder(EquipmentSlot.CHEST)`.

**Этот проект ещё не прошёл настоящую сборку или запуск в Minecraft в среде автора.** Не устанавливай предыдущий файл `elytra-armor-upgrade-1.0.0-UNVERIFIED.jar`: он был собран с заглушками и вызвал исходный вылет.

## Сборка на Windows

1. Установи JDK 25 (именно JDK, не только Java Runtime).
2. Убедись, что `java -version` показывает версию 25.
3. Открой терминал в корне проекта — там, где находятся `build.gradle` и `gradlew.bat`.
4. Выполни `gradlew.bat clean build`. Нужен доступ к официальным репозиториям Gradle, Fabric и Minecraft.
5. При успешной сборке ищи файл `build\libs\elytra-armor-upgrade-1.0.1.jar`. Не устанавливай `*-sources.jar`.

## Сборка через GitHub Actions

В репозитории есть `.github/workflows/build.yml`. После загрузки проекта в GitHub и включения Actions workflow собирает проект с JDK 25 и сохраняет JAR как workflow artifact. Открой вкладку **Actions**, выбери завершившийся запуск **Build Fabric mod**, затем скачай artifact внизу страницы.

## Зависимости

- Minecraft Java Edition 26.3
- Java/JDK 25
- Fabric Loader 0.19.5 или новее
- Fabric API для 26.3

## Перед использованием

Сначала запусти сборку в отдельном профиле Minecraft 26.3 + Fabric API. Проверь рецепты всех трёх уровней, защитные атрибуты, полёт, зачарование через стол и наковальню, перенос урона/имени/зачарований при апгрейде. Не проверяй первую сборку на единственном экземпляре важного мира — сделай резервную копию.
