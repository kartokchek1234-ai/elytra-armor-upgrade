@echo off
setlocal EnableExtensions
set "GRADLE_VERSION=9.7.1"
if not defined GRADLE_USER_HOME set "GRADLE_USER_HOME=%USERPROFILE%\.gradle"
set "GRADLE_DIR=%GRADLE_USER_HOME%\manual-wrapper\gradle-%GRADLE_VERSION%"
set "GRADLE_BIN=%GRADLE_DIR%\gradle-%GRADLE_VERSION%\bin\gradle.bat"
where java >nul 2>nul
if errorlevel 1 (
  echo Java 25 or newer is required. Install a JDK 25 and retry.
  exit /b 1
)
for /f "tokens=3" %%v in ('java -XshowSettings:properties -version 2^>^&1 ^| findstr "java.specification.version"') do set "JAVA_MAJOR=%%v"
if not defined JAVA_MAJOR (
  echo Could not determine the installed Java version. Install JDK 25.
  exit /b 1
)
if %JAVA_MAJOR% LSS 25 (
  echo Java 25 or newer is required; detected Java %JAVA_MAJOR%.
  exit /b 1
)
if not exist "%GRADLE_BIN%" (
  echo Downloading Gradle %GRADLE_VERSION%...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $dir='%GRADLE_DIR%'; $zip=Join-Path $env:TEMP 'gradle-%GRADLE_VERSION%-elytra.zip'; New-Item -ItemType Directory -Force -Path (Split-Path $dir) | Out-Null; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile $zip; Expand-Archive -Force $zip $dir; Remove-Item $zip"
  if errorlevel 1 exit /b 1
)
call "%GRADLE_BIN%" %*
exit /b %ERRORLEVEL%
