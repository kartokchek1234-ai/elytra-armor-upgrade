package io.github.elytraarmorupgrade.recipe;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import io.github.elytraarmorupgrade.item.ModItems;
import net.minecraft.core.Registry;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.crafting.CraftingInput;
import net.minecraft.world.item.crafting.CustomRecipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.level.Level;

import java.util.List;

/**
 * A shapeless 3x3 crafting recipe with strict ingredient counts.
 * The input must occupy exactly eight crafting slots: one base item and seven resources.
 */
public final class ElytraUpgradeRecipe extends CustomRecipe {
    public static final MapCodec<ElytraUpgradeRecipe> CODEC = Codec.intRange(1, 3)
            .fieldOf("level")
            .xmap(ElytraUpgradeRecipe::new, ElytraUpgradeRecipe::level);

    public static final StreamCodec<RegistryFriendlyByteBuf, ElytraUpgradeRecipe> STREAM_CODEC =
            StreamCodec.composite(ByteBufCodecs.VAR_INT, ElytraUpgradeRecipe::level, ElytraUpgradeRecipe::new);

    public static final RecipeSerializer<ElytraUpgradeRecipe> SERIALIZER =
            new RecipeSerializer<>(CODEC, STREAM_CODEC);

    private final int level;

    public ElytraUpgradeRecipe(int level) {
        this.level = level;
    }

    public int level() {
        return level;
    }

    @Override
    public boolean matches(CraftingInput input, Level level) {
        return !findBase(input).isEmpty();
    }

    @Override
    public ItemStack assemble(CraftingInput input) {
        ItemStack base = findBase(input);
        if (base.isEmpty()) {
            return ItemStack.EMPTY;
        }

        Item target = switch (this.level) {
            case 1 -> ModItems.REINFORCED_ELYTRA;
            case 2 -> ModItems.ARMORED_ELYTRA;
            case 3 -> ModItems.DEFENDER_ELYTRA;
            default -> throw new IllegalStateException("Unsupported elytra upgrade level: " + this.level);
        };

        ItemStack result = new ItemStack(target);
        // Keep the target tier's mechanically important defaults before applying the source patch.
        var tierAttributes = result.get(DataComponents.ATTRIBUTE_MODIFIERS);
        var tierEquippable = result.get(DataComponents.EQUIPPABLE);
        var tierGlider = result.get(DataComponents.GLIDER);
        var tierEnchantable = result.get(DataComponents.ENCHANTABLE);
        var tierMaxDamage = result.get(DataComponents.MAX_DAMAGE);

        // Only patched data is copied; the target item keeps its own armor and glide configuration.
        result.applyComponents(base.getComponentsPatch());
        result.set(DataComponents.ATTRIBUTE_MODIFIERS, tierAttributes);
        result.set(DataComponents.EQUIPPABLE, tierEquippable);
        result.set(DataComponents.GLIDER, tierGlider);
        result.set(DataComponents.ENCHANTABLE, tierEnchantable);
        result.set(DataComponents.MAX_DAMAGE, tierMaxDamage);
        return result;
    }

    @Override
    public RecipeSerializer<? extends CustomRecipe> getSerializer() {
        return SERIALIZER;
    }

    private ItemStack findBase(CraftingInput input) {
        List<ItemStack> stacks = input.items();
        // A crafting grid keeps all of its slots (including empty ones) in this list.
        // Eight slots must be occupied, and each occupied slot must hold exactly one item:
        // vanilla crafting consumes one item per slot, not the whole input stack.
        int occupiedSlots = 0;
        for (ItemStack stack : stacks) {
            if (!stack.isEmpty()) {
                occupiedSlots++;
                if (stack.getCount() != 1) {
                    return ItemStack.EMPTY;
                }
            }
        }
        if (occupiedSlots != 8) {
            return ItemStack.EMPTY;
        }

        Item baseType = switch (this.level) {
            case 1 -> Items.ELYTRA;
            case 2 -> ModItems.REINFORCED_ELYTRA;
            case 3 -> ModItems.ARMORED_ELYTRA;
            default -> null;
        };
        if (baseType == null) {
            return ItemStack.EMPTY;
        }

        ItemStack base = ItemStack.EMPTY;
        int diamonds = 0;
        int membranes = 0;
        int scraps = 0;
        int crystals = 0;
        int netherStars = 0;
        int ingots = 0;
        int echoShards = 0;

        for (ItemStack stack : stacks) {
            if (stack.isEmpty()) {
                continue;
            }
            if (stack.is(baseType)) {
                if (!base.isEmpty()) {
                    return ItemStack.EMPTY;
                }
                base = stack;
            } else if (stack.is(Items.DIAMOND)) {
                diamonds++;
            } else if (stack.is(Items.PHANTOM_MEMBRANE)) {
                membranes++;
            } else if (stack.is(Items.NETHERITE_SCRAP)) {
                scraps++;
            } else if (stack.is(Items.END_CRYSTAL)) {
                crystals++;
            } else if (stack.is(Items.NETHER_STAR)) {
                netherStars++;
            } else if (stack.is(Items.NETHERITE_INGOT)) {
                ingots++;
            } else if (stack.is(Items.ECHO_SHARD)) {
                echoShards++;
            } else {
                return ItemStack.EMPTY;
            }
        }

        if (base.isEmpty()) {
            return ItemStack.EMPTY;
        }

        boolean correctIngredients = switch (this.level) {
            case 1 -> diamonds == 4 && membranes == 2 && scraps == 1
                    && crystals == 0 && netherStars == 0 && ingots == 0 && echoShards == 0;
            case 2 -> diamonds == 2 && scraps == 4 && crystals == 1
                    && membranes == 0 && netherStars == 0 && ingots == 0 && echoShards == 0;
            case 3 -> netherStars == 1 && ingots == 4 && echoShards == 2
                    && diamonds == 0 && membranes == 0 && scraps == 0 && crystals == 0;
            default -> false;
        };

        return correctIngredients ? base : ItemStack.EMPTY;
    }
}
